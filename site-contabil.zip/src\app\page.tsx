import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  Building2,
  Calculator,
  FileCheck2,
  FileText,
  Handshake,
  Landmark,
  LineChart,
  Receipt,
  ShieldCheck,
  Users,
  PhoneCall,
  CheckCircle2,
  MapPin,
} from "lucide-react";
import { site, servicos, diferenciais, etapas, faqs, whatsappLink } from "@/site";
import Faq from "@/components/Faq";
import SectionHeading from "@/components/SectionHeading";
import CtaBanner from "@/components/CtaBanner";

export const metadata: Metadata = {
  title: "Contabilidade para empresas",
  description:
    "Tenha mais clareza sobre suas obrigações contábeis, organização fiscal e informações financeiras para tomar decisões melhores.",
};

const iconesServicos: Record<string, React.ReactNode> = {
  abertura: <Building2 className="h-6 w-6" aria-hidden />,
  contabilidade: <Calculator className="h-6 w-6" aria-hidden />,
  tributario: <Landmark className="h-6 w-6" aria-hidden />,
  fiscal: <Receipt className="h-6 w-6" aria-hidden />,
  pessoal: <Users className="h-6 w-6" aria-hidden />,
  regularizacao: <FileCheck2 className="h-6 w-6" aria-hidden />,
  mei: <FileText className="h-6 w-6" aria-hidden />,
  consultoria: <LineChart className="h-6 w-6" aria-hidden />,
};

export default function Home() {
  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden bg-navy-950 text-white">
        <div
          aria-hidden
          className="absolute inset-0 bg-[radial-gradient(900px_420px_at_85%_-10%,rgba(35,136,92,.35),transparent),radial-gradient(700px_380px_at_10%_10%,rgba(53,97,158,.45),transparent)]"
        />
        <div aria-hidden className="absolute inset-0 opacity-[0.12] [background-image:linear-gradient(rgba(255,255,255,.6)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.6)_1px,transparent_1px)] [background-size:44px_44px] [mask-image:radial-gradient(ellipse_at_center,black,transparent_75%)]" />
        <div className="relative mx-auto max-w-6xl px-5 pb-16 pt-14 sm:pt-20 lg:grid lg:grid-cols-[1.05fr_.95fr] lg:gap-12 lg:pb-24">
          <div>
            <p className="animate-fade-up inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-medium tracking-wide text-white/90">
              <ShieldCheck className="h-4 w-4 text-emerald-300" aria-hidden />
              Contabilidade para MEIs, Simples, Presumido e Lucro Real
            </p>
            <h1 className="animate-fade-up animate-fade-up-1 mt-5 font-display text-4xl font-bold leading-[1.08] sm:text-5xl lg:text-[3.4rem]">
              Sua empresa cresce.
              <br />
              <span className="text-emerald-300">Sua contabilidade acompanha.</span>
            </h1>
            <p className="animate-fade-up animate-fade-up-2 mt-5 max-w-xl text-base leading-relaxed text-white/80 sm:text-lg">
              Tenha mais clareza sobre suas obrigações contábeis, organização fiscal e informações
              financeiras para tomar decisões melhores.
            </p>
            <div className="animate-fade-up animate-fade-up-3 mt-8 flex flex-col gap-3 sm:flex-row">
              <a
                href={whatsappLink(site.whatsappMensagens.geral)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-brand-500 px-6 py-3.5 font-semibold text-white shadow-soft transition hover:bg-brand-600"
              >
                <PhoneCall className="h-5 w-5" aria-hidden />
                Fale com um contador
              </a>
              <Link
                href="/servicos"
                className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/25 bg-white/5 px-6 py-3.5 font-semibold text-white transition hover:bg-white/10"
              >
                Conheça nossos serviços
                <ArrowRight className="h-5 w-5" aria-hidden />
              </Link>
            </div>
            <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-white/70">
              {["Resposta no horário comercial", "Proposta transparente", "Transição assistida"].map(
                (t) => (
                  <li key={t} className="inline-flex items-center gap-1.5">
                    <CheckCircle2 className="h-4 w-4 text-emerald-300" aria-hidden />
                    {t}
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Card visual profissional */}
          <div className="animate-fade-up animate-fade-up-2 mt-10 lg:mt-0">
            <div className="rounded-2xl border border-white/15 bg-white/[.07] p-6 shadow-soft backdrop-blur">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-white/90">Rotina contábil mensal</p>
                <span className="rounded-full bg-emerald-400/15 px-3 py-1 text-xs font-semibold text-emerald-200">
                  Em dia
                </span>
              </div>
              <div className="mt-5 space-y-3">
                {[
                  ["Notas fiscais conferidas", "100%"],
                  ["Guias e impostos apurados", "100%"],
                  ["Folha e eSocial processados", "100%"],
                  ["Relatórios para decisão", "Mensal"],
                ].map(([k, v]) => (
                  <div
                    key={k}
                    className="flex items-center justify-between rounded-xl bg-white/[.06] px-4 py-3 text-sm"
                  >
                    <span className="text-white/85">{k}</span>
                    <span className="font-semibold text-emerald-200">{v}</span>
                  </div>
                ))}
              </div>
              <div className="mt-5 rounded-xl bg-navy-900/60 p-4 text-sm text-white/75">
                <p className="font-semibold text-white">Como começamos?</p>
                <p className="mt-1 leading-relaxed">
                  Diagnóstico da sua empresa, proposta clara e calendário de obrigações desde o
                  primeiro mês.
                </p>
                <a
                  href={whatsappLink(site.whatsappMensagens.proposta)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-flex items-center gap-1.5 font-semibold text-emerald-300 hover:text-emerald-200"
                >
                  Pedir proposta <ArrowRight className="h-4 w-4" aria-hidden />
                </a>
              </div>
            </div>
            <p className="mt-3 flex items-center gap-1.5 text-xs text-white/50">
              <MapPin className="h-3.5 w-3.5" aria-hidden />
              Atendimento em {site.endereco.cidade}–{site.endereco.uf} e em todo o Brasil.
            </p>
          </div>
        </div>
      </section>

      {/* SERVIÇOS */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:py-20" aria-labelledby="servicos-titulo">
        <SectionHeading
          id="servicos-titulo"
          eyebrow="Serviços"
          titulo="Contabilidade completa para cada fase da empresa"
          descricao="Do CNPJ novo à operação consolidada: escolha o serviço ou fale com a equipe para montar o escopo ideal."
        />
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {servicos.map((s) => (
            <article
              key={s.id}
              className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-6 shadow-card transition hover:-translate-y-1 hover:shadow-soft"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-navy-900 text-white transition group-hover:bg-brand-600">
                {iconesServicos[s.id]}
              </div>
              <h3 className="mt-4 font-display text-lg font-semibold text-navy-900">{s.titulo}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-slate-600">{s.descricao}</p>
              <Link
                href={`/servicos#${s.id}`}
                className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-brand-700 hover:text-brand-600"
              >
                Saber mais <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
            </article>
          ))}
        </div>
      </section>

      {/* DIFERENCIAIS */}
      <section className="bg-slate-50" aria-labelledby="diferenciais-titulo">
        <div className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
          <SectionHeading
            id="diferenciais-titulo"
            eyebrow="Diferenciais"
            titulo="Uma contabilidade que organiza, orienta e acompanha"
            descricao="Sem promessas irreais. Nosso compromisso é com processo, prazo e informação útil para o dia a dia."
          />
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {diferenciais.map((d, i) => (
              <div key={d.titulo} className="rounded-2xl border border-slate-200 bg-white p-6">
                <span className="text-xs font-bold tracking-widest text-brand-600">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="mt-2 font-display text-lg font-semibold text-navy-900">{d.titulo}</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">{d.descricao}</p>
              </div>
            ))}
            <div className="flex flex-col justify-between rounded-2xl bg-navy-900 p-6 text-white">
              <div>
                <Handshake className="h-8 w-8 text-emerald-300" aria-hidden />
                <h3 className="mt-3 font-display text-lg font-semibold">
                  Compromisso com o cliente
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-white/75">
                  Transparência em honorários, prazos combinados e comunicação clara em cada entrega.
                </p>
              </div>
              <a
                href={whatsappLink()}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-5 inline-flex items-center justify-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-semibold text-navy-900 transition hover:bg-slate-100"
              >
                Conversar agora <ArrowRight className="h-4 w-4" aria-hidden />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section className="mx-auto max-w-6xl px-5 py-16 sm:py-20" aria-labelledby="como-funciona">
        <SectionHeading
          id="como-funciona"
          eyebrow="Como funciona"
          titulo="Do primeiro contato ao atendimento mensal em 4 etapas"
        />
        <ol className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {etapas.map((e, i) => (
            <li key={e.titulo} className="relative rounded-2xl border border-slate-200 bg-white p-6">
              <span
                aria-hidden
                className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-50 font-display text-sm font-bold text-brand-700"
              >
                {i + 1}
              </span>
              <h3 className="mt-3 font-display font-semibold text-navy-900">{e.titulo}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{e.descricao}</p>
            </li>
          ))}
        </ol>
        <div className="mt-8 text-center">
          <Link
            href="/contato"
            className="inline-flex items-center gap-2 rounded-xl bg-navy-900 px-6 py-3.5 font-semibold text-white transition hover:bg-navy-800"
          >
            Solicitar proposta <ArrowRight className="h-5 w-5" aria-hidden />
          </Link>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-slate-50" aria-labelledby="faq-titulo">
        <div className="mx-auto max-w-3xl px-5 py-16 sm:py-20">
          <SectionHeading
            id="faq-titulo"
            eyebrow="Dúvidas frequentes"
            titulo="Perguntas frequentes"
            descricao="Respostas objetivas. Para o seu caso específico, fale com a equipe."
            align="center"
          />
          <Faq itens={[...faqs]} />
          <p className="mt-6 text-center text-sm text-slate-600">
            Não achou sua dúvida?{" "}
            <a
              href={whatsappLink("Olá! Tenho uma dúvida sobre contabilidade.")}
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-brand-700 underline underline-offset-2"
            >
              Pergunte no WhatsApp
            </a>
            .
          </p>
        </div>
      </section>

      <CtaBanner />
    </>
  );
}
