"use client";

import { useState } from "react";
import { Loader2, CheckCircle2, AlertCircle, MessageCircle } from "lucide-react";
import { servicos, site, whatsappLink } from "@/site";

type Erros = Partial<Record<"nome" | "empresa" | "telefone" | "email" | "servico" | "mensagem" | "lgpd" | "geral", string>>;

const emailValido = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());
const telefoneValido = (v: string) => v.replace(/\D/g, "").length >= 10;

export default function ContactForm() {
  const [nome, setNome] = useState("");
  const [empresa, setEmpresa] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");
  const [servico, setServico] = useState("");
  const [mensagem, setMensagem] = useState("");
  const [lgpd, setLgpd] = useState(false);
  const [erros, setErros] = useState<Erros>({});
  const [status, setStatus] = useState<"idle" | "enviando" | "ok" | "erro">("idle");
  const [msgStatus, setMsgStatus] = useState("");

  function validar(): Erros {
    const e: Erros = {};
    if (nome.trim().length < 2) e.nome = "Informe seu nome completo.";
    if (empresa.trim().length < 2) e.empresa = "Informe o nome da empresa.";
    if (!telefoneValido(telefone)) e.telefone = "Informe um telefone válido com DDD.";
    if (!emailValido(email)) e.email = "Informe um e-mail válido.";
    if (!servico) e.servico = "Selecione o serviço desejado.";
    if (mensagem.trim().length < 10) e.mensagem = "Descreva sua necessidade com ao menos 10 caracteres.";
    if (!lgpd) e.lgpd = "É necessário autorizar o contato (LGPD).";
    return e;
  }

  async function onSubmit(ev: React.FormEvent) {
    ev.preventDefault();
    const v = validar();
    setErros(v);
    if (Object.keys(v).length > 0) {
      setStatus("idle");
      document.getElementById("form-erros")?.focus();
      return;
    }
    setStatus("enviando");
    setMsgStatus("");
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, empresa, telefone, email, servico, mensagem, lgpd }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data?.erro || "Não foi possível enviar. Tente pelo WhatsApp.");
      }
      setStatus("ok");
      setMsgStatus("Recebemos sua mensagem. Retornaremos no horário comercial. Se preferir, chame no WhatsApp.");
      setNome(""); setEmpresa(""); setTelefone(""); setEmail(""); setServico(""); setMensagem(""); setLgpd(false);
      setErros({});
    } catch (err) {
      setStatus("erro");
      setMsgStatus(err instanceof Error ? err.message : "Erro ao enviar. Tente novamente ou use o WhatsApp.");
    }
  }

  const inputCls = (comErro?: string) =>
    `w-full rounded-xl border px-4 py-3 text-sm outline-none transition placeholder:text-slate-400 ${
      comErro
        ? "border-red-400 bg-red-50/50 focus:border-red-500"
        : "border-slate-300 focus:border-brand-600 focus:ring-2 focus:ring-brand-100"
    }`;

  return (
    <form onSubmit={onSubmit} noValidate aria-describedby="form-erros" className="rounded-2xl border border-slate-200 bg-white p-6 shadow-card sm:p-8">
      <div id="form-erros" tabIndex={-1} aria-live="polite">
        {Object.keys(erros).length > 0 && (
          <div role="alert" className="mb-5 flex items-start gap-2 rounded-xl bg-red-50 p-4 text-sm text-red-800">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            <span>Verifique os campos destacados abaixo.</span>
          </div>
        )}
        {status === "ok" && (
          <div role="status" className="mb-5 flex items-start gap-2 rounded-xl bg-emerald-50 p-4 text-sm text-emerald-900">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            <span>{msgStatus}</span>
          </div>
        )}
        {status === "erro" && (
          <div role="alert" className="mb-5 rounded-xl bg-red-50 p-4 text-sm text-red-800">
            <p className="flex items-start gap-2">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
              <span>{msgStatus}</span>
            </p>
            <a
              href={whatsappLink(`Olá! Sou ${nome || "visitante do site"} e gostaria de atendimento.`)}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center gap-1.5 font-semibold underline underline-offset-2"
            >
              <MessageCircle className="h-4 w-4" aria-hidden /> Continuar pelo WhatsApp
            </a>
          </div>
        )}
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="nome" className="mb-1.5 block text-sm font-medium text-navy-900">Nome *</label>
          <input id="nome" name="nome" autoComplete="name" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Seu nome" className={inputCls(erros.nome)} aria-invalid={!!erros.nome} aria-describedby={erros.nome ? "erro-nome" : undefined} />
          {erros.nome && <p id="erro-nome" className="mt-1 text-xs text-red-600">{erros.nome}</p>}
        </div>
        <div>
          <label htmlFor="empresa" className="mb-1.5 block text-sm font-medium text-navy-900">Nome da empresa *</label>
          <input id="empresa" name="empresa" autoComplete="organization" value={empresa} onChange={(e) => setEmpresa(e.target.value)} placeholder="Razão social ou fantasia" className={inputCls(erros.empresa)} aria-invalid={!!erros.empresa} />
          {erros.empresa && <p className="mt-1 text-xs text-red-600">{erros.empresa}</p>}
        </div>
        <div>
          <label htmlFor="telefone" className="mb-1.5 block text-sm font-medium text-navy-900">Telefone / WhatsApp *</label>
          <input id="telefone" name="telefone" inputMode="tel" autoComplete="tel" value={telefone} onChange={(e) => setTelefone(e.target.value)} placeholder="(11) 99999-9999" className={inputCls(erros.telefone)} aria-invalid={!!erros.telefone} />
          {erros.telefone && <p className="mt-1 text-xs text-red-600">{erros.telefone}</p>}
        </div>
        <div>
          <label htmlFor="email" className="mb-1.5 block text-sm font-medium text-navy-900">E-mail *</label>
          <input id="email" name="email" type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@empresa.com.br" className={inputCls(erros.email)} aria-invalid={!!erros.email} />
          {erros.email && <p className="mt-1 text-xs text-red-600">{erros.email}</p>}
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="servico" className="mb-1.5 block text-sm font-medium text-navy-900">Serviço desejado *</label>
          <select id="servico" name="servico" value={servico} onChange={(e) => setServico(e.target.value)} className={inputCls(erros.servico)} aria-invalid={!!erros.servico}>
            <option value="">Selecione…</option>
            {servicos.map((s) => (
              <option key={s.id} value={s.titulo}>{s.titulo}</option>
            ))}
            <option value="Outro">Outro / ainda não sei</option>
          </select>
          {erros.servico && <p className="mt-1 text-xs text-red-600">{erros.servico}</p>}
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="mensagem" className="mb-1.5 block text-sm font-medium text-navy-900">Mensagem *</label>
          <textarea id="mensagem" name="mensagem" rows={5} value={mensagem} onChange={(e) => setMensagem(e.target.value)} placeholder="Conte um pouco sobre sua empresa e o que você precisa…" className={`${inputCls(erros.mensagem)} resize-y`} aria-invalid={!!erros.mensagem} />
          {erros.mensagem && <p className="mt-1 text-xs text-red-600">{erros.mensagem}</p>}
        </div>
      </div>

      <div className="mt-4 flex items-start gap-2.5">
        <input id="lgpd" type="checkbox" checked={lgpd} onChange={(e) => setLgpd(e.target.checked)} className="mt-1 h-4 w-4 accent-[#18714b]" aria-describedby={erros.lgpd ? "erro-lgpd" : undefined} />
        <label htmlFor="lgpd" className="text-xs leading-relaxed text-slate-600">
          Autorizo o contato e o tratamento dos meus dados para retorno da solicitação, conforme a{" "}
          <a href="/privacidade" className="font-semibold text-brand-700 underline underline-offset-2">Política de privacidade</a> (LGPD – Lei nº 13.709/2018). *
        </label>
      </div>
      {erros.lgpd && <p id="erro-lgpd" className="mt-1 text-xs text-red-600">{erros.lgpd}</p>}

      <button
        type="submit"
        disabled={status === "enviando"}
        className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-navy-900 px-6 py-3.5 font-semibold text-white transition hover:bg-navy-800 disabled:opacity-60 sm:w-auto"
      >
        {status === "enviando" && <Loader2 className="h-5 w-5 animate-spin" aria-hidden />}
        {status === "enviando" ? "Enviando…" : "Enviar mensagem"}
      </button>
      <p className="mt-3 text-xs text-slate-500">
        Prefere WhatsApp?{" "}
        <a href={whatsappLink(site.whatsappMensagens.geral)} target="_blank" rel="noopener noreferrer" className="font-semibold text-brand-700 underline underline-offset-2">
          Chame aqui
        </a>.
      </p>
    </form>
  );
}
