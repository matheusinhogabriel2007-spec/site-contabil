// ============================================================
// CONFIGURAÇÃO CENTRAL DO SITE
// Edite aqui telefone, WhatsApp, e-mail, endereço, nome e cores.
// Nenhum dado real foi inventado: preencha com os dados do escritório.
// ============================================================

export const site = {
  nome: "CONTÁBIL",
  nomeCompleto: "Contábil — Escritório de Contabilidade",
  tagline: "Contabilidade clara para empresas que querem crescer.",
  descricao:
    "Escritório de contabilidade no Brasil. Abertura de empresas, contabilidade empresarial, fiscal, departamento pessoal, MEI e consultoria.",
  // Use DDI+DDD+numero, só dígitos. Ex: 5511999999999
  whatsappNumero: "5511999999999",
  telefoneExibicao: "(11) 99999-9999",
  telefoneHref: "tel:+5511999999999",
  email: "contato@contabil.exemplo.com.br",
  endereco: {
    rua: "Rua Exemplo, 123 — Sala 45",
    cidade: "São Paulo",
    uf: "SP",
    cep: "01000-000",
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=S%C3%A3o+Paulo+SP",
  },
  horario: "Seg–Sex, 8h às 18h",
  redes: {
    instagram: "https://instagram.com/",
    linkedin: "https://linkedin.com/",
    facebook: "https://facebook.com/",
  },
  // Mensagens pré-preenchidas do WhatsApp
  whatsappMensagens: {
    geral: "Olá! Vim pelo site e gostaria de falar com um contador.",
    proposta: "Olá! Gostaria de receber uma proposta dos serviços contábeis.",
  },
  urlBase: "https://www.contabil.exemplo.com.br",
} as const;

export function whatsappLink(mensagem: string = site.whatsappMensagens.geral): string {
  const texto = encodeURIComponent(mensagem);
  return `https://wa.me/${site.whatsappNumero}?text=${texto}`;
}

export type ServicoId =
  | "abertura"
  | "contabilidade"
  | "tributario"
  | "fiscal"
  | "pessoal"
  | "regularizacao"
  | "mei"
  | "consultoria";

export const servicos: Array<{
  id: ServicoId;
  titulo: string;
  descricao: string;
  detalhes: string[];
}> = [
  {
    id: "abertura",
    titulo: "Abertura de empresas",
    descricao:
      "Orientação na escolha do regime tributário, CNAEs e tipo societário, com acompanhamento do processo de legalização.",
    detalhes: [
      "Análise de regime tributário (Simples, Presumido, Real)",
      "Orientação sobre CNAEs e objeto social",
      "Acompanhamento de viabilidade, DBE, Junta e alvarás",
    ],
  },
  {
    id: "contabilidade",
    titulo: "Contabilidade empresarial",
    descricao:
      "Escrituração contábil organizada, demonstrações financeiras e rotinas mensais para manter a empresa em dia.",
    detalhes: [
      "Classificação e conciliação contábil mensal",
      "Balanço patrimonial e DRE",
      "Entrega das obrigações acessórias contábeis",
    ],
  },
  {
    id: "tributario",
    titulo: "Planejamento tributário",
    descricao:
      "Análise da carga tributária e do enquadramento fiscal para identificar a opção mais adequada ao perfil da empresa.",
    detalhes: [
      "Comparativo entre regimes tributários",
      "Calendário de vencimentos e obrigações",
      "Revisão periódica do enquadramento",
    ],
  },
  {
    id: "fiscal",
    titulo: "Departamento fiscal",
    descricao:
      "Apuração de impostos, emissão e validação de notas fiscais e entrega das obrigações fiscais no prazo.",
    detalhes: [
      "Apuração de IRPJ, CSLL, PIS, COFINS, ICMS e ISS",
      "Conferência de notas fiscais de entrada e saída",
      "SPED, EFD e declarações conforme o regime",
    ],
  },
  {
    id: "pessoal",
    titulo: "Departamento pessoal e folha",
    descricao:
      "Gestão de admissões, folha de pagamento, férias, rescisões e obrigações trabalhistas e previdenciárias.",
    detalhes: [
      "Folha, pró-labore, férias e 13º",
      "Admissões, demissões e eSocial",
      "Guias FGTS, INSS e DIRF",
    ],
  },
  {
    id: "regularizacao",
    titulo: "Regularização de empresas",
    descricao:
      "Diagnóstico de pendências cadastrais e fiscais e condução do processo de regularização junto aos órgãos.",
    detalhes: [
      "Diagnóstico de CNPJs, certidões e débitos",
      "Parcelamentos e negociação quando aplicável",
      "Atualização cadastral e reativação",
    ],
  },
  {
    id: "mei",
    titulo: "Contabilidade para MEI",
    descricao:
      "Organização das obrigações do MEI, limite de faturamento e orientação para o crescimento para ME.",
    detalhes: [
      "DAS mensal e Declaração Anual (DASN-SIMEI)",
      "Controle de faturamento e desenquadramento",
      "Emissão de notas e organização financeira básica",
    ],
  },
  {
    id: "consultoria",
    titulo: "Consultoria contábil e financeira",
    descricao:
      "Leitura dos números da empresa para apoiar decisões: precificação, custos e organização financeira.",
    detalhes: [
      "Análise de demonstrativos e indicadores",
      "Apoio em precificação e margem",
      "Rotinas de organização financeira",
    ],
  },
];

export const diferenciais = [
  {
    titulo: "Atendimento próximo",
    descricao:
      "Canal direto com a equipe contábil e acompanhamento contínuo da rotina da empresa.",
  },
  {
    titulo: "Organização contábil",
    descricao:
      "Processos claros de envio, conferência e guarda de documentos, mês a mês.",
  },
  {
    titulo: "Orientação tributária",
    descricao:
      "Explicações objetivas sobre impostos e obrigações, sem juridiquês desnecessário.",
  },
  {
    titulo: "Cumprimento das obrigações",
    descricao:
      "Controle de prazos e entregas para reduzir riscos de multas e pendências.",
  },
  {
    titulo: "Informações para decisões",
    descricao:
      "Relatórios e leituras financeiras que ajudam o empresário a decidir com mais segurança.",
  },
] as const;

export const etapas = [
  {
    titulo: "Primeiro contato",
    descricao:
      "Você chama no WhatsApp ou envia o formulário. Retornamos no horário comercial.",
  },
  {
    titulo: "Entendimento das necessidades",
    descricao:
      "Coletamos informações sobre a empresa, o momento e as obrigações atuais.",
  },
  {
    titulo: "Apresentação da proposta",
    descricao:
      "Você recebe escopo, prazos, documentos necessários e honorários de forma transparente.",
  },
  {
    titulo: "Início do atendimento",
    descricao:
      "Organizamos a transição, o acesso aos sistemas e o calendário contábil mensal.",
  },
] as const;

export const faqs = [
  {
    pergunta: "Como funciona a troca de contador?",
    resposta:
      "Em geral, você comunica o encerramento ao contador atual, solicita a documentação e as senhas de acesso e o novo escritório assume a rotina a partir de uma data combinada. Ajudamos com a lista de documentos e a transição para evitar gaps nas obrigações.",
  },
  {
    pergunta: "Quanto custa um serviço contábil?",
    resposta:
      "O valor depende do regime tributário, do faturamento, do volume de notas e funcionários e dos serviços incluídos. Por isso trabalhamos com proposta personalizada após entender a realidade da empresa. Chame no WhatsApp para receber uma estimativa sem compromisso.",
  },
  {
    pergunta: "O que preciso para abrir uma empresa?",
    resposta:
      "Normalmente: documentos dos sócios, definição de atividade (CNAE), endereço, capital social e regime tributário. O prazo varia por cidade e atividade. Cuidamos da orientação e do acompanhamento em Junta Comercial, Receita, prefeitura e órgãos específicos quando houver.",
  },
  {
    pergunta: "Quais são as obrigações do MEI?",
    resposta:
      "O MEI paga o DAS mensal, entrega a Declaração Anual (DASN-SIMEI) e deve respeitar o limite de faturamento e as regras de contratação. Também precisa organizar notas e comprovantes. Ajudamos a manter tudo em dia e a avaliar o momento de migrar para ME.",
  },
  {
    pergunta: "O que é planejamento tributário?",
    resposta:
      "É a análise do regime tributário e da operação da empresa para verificar se o enquadramento atual é o mais adequado. Não se trata de promessa de economia, mas de um estudo técnico e revisões periódicas conforme a empresa muda.",
  },
  {
    pergunta: "Quais documentos preciso enviar todo mês?",
    resposta:
      "Em geral: notas fiscais emitidas e recebidas, extratos bancários, comprovantes de pagamentos, folha e informações de funcionários, e contratos relevantes. Após a proposta, você recebe uma lista objetiva e um canal de envio organizado.",
  },
] as const;
