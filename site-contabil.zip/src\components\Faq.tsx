"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

export default function Faq({ itens }: { itens: Array<{ pergunta: string; resposta: string }> }) {
  const [aberto, setAberto] = useState<number | null>(0);

  return (
    <div className="mt-8 divide-y divide-slate-200 rounded-2xl border border-slate-200 bg-white">
      {itens.map((f, i) => {
        const isAberto = aberto === i;
        return (
          <div key={f.pergunta}>
            <button
              type="button"
              onClick={() => setAberto(isAberto ? null : i)}
              aria-expanded={isAberto}
              aria-controls={`faq-painel-${i}`}
              className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
            >
              <span className="font-medium text-navy-900">{f.pergunta}</span>
              <ChevronDown
                className={`h-5 w-5 shrink-0 text-brand-600 transition-transform ${isAberto ? "rotate-180" : ""}`}
                aria-hidden
              />
            </button>
            {isAberto && (
              <div id={`faq-painel-${i}`} className="px-5 pb-5 text-sm leading-relaxed text-slate-600">
                {f.resposta}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
