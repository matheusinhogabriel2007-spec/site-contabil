"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

const CHAVE = "contabil-lgpd-consentimento";

export default function CookieConsent() {
  const [visivel, setVisivel] = useState(false);

  useEffect(() => {
    try {
      if (!localStorage.getItem(CHAVE)) setVisivel(true);
    } catch {
      setVisivel(true);
    }
  }, []);

  function aceitar() {
    try {
      localStorage.setItem(CHAVE, JSON.stringify({ aceite: true, data: new Date().toISOString() }));
    } catch {}
    setVisivel(false);
  }

  if (!visivel) return null;

  return (
    <div role="dialog" aria-live="polite" aria-label="Aviso de privacidade" className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-xl rounded-2xl border border-slate-200 bg-white p-5 shadow-soft sm:bottom-6 sm:left-6 sm:right-auto">
      <p className="text-sm font-semibold text-navy-900">Privacidade e LGPD</p>
      <p className="mt-1 text-sm leading-relaxed text-slate-600">
        Usamos apenas o necessário para o funcionamento do site. Ao enviar o formulário, você
        concorda com o uso dos dados para retorno do contato. Veja a{" "}
        <Link href="/privacidade" className="font-semibold text-brand-700 underline underline-offset-2">
          Política de privacidade
        </Link>
        .
      </p>
      <div className="mt-3 flex gap-2">
        <button
          type="button"
          onClick={aceitar}
          className="rounded-xl bg-navy-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-navy-800"
        >
          Entendi
        </button>
      </div>
    </div>
  );
}
