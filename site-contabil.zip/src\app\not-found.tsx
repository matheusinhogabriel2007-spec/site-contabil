import Link from "next/link";
import { ArrowLeft, MessageCircle } from "lucide-react";
import { site, whatsappLink } from "@/site";

export default function NotFound() {
  return (
    <section className="mx-auto max-w-2xl px-5 py-20 text-center">
      <p className="font-display text-7xl font-bold text-navy-900">404</p>
      <h1 className="mt-3 font-display text-2xl font-bold text-navy-900">Página não encontrada</h1>
      <p className="mt-2 text-slate-600">
        O endereço pode ter mudado ou não existe mais. Volte ao início ou fale com a equipe.
      </p>
      <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
        <Link
          href="/"
          className="inline-flex items-center justify-center gap-2 rounded-xl bg-navy-900 px-6 py-3 font-semibold text-white hover:bg-navy-800"
        >
          <ArrowLeft className="h-5 w-5" aria-hidden /> Voltar ao início
        </Link>
        <a
          href={whatsappLink("Olá! Não encontrei uma página no site e preciso de ajuda.")}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300 px-6 py-3 font-semibold text-navy-900 hover:bg-slate-50"
        >
          <MessageCircle className="h-5 w-5" aria-hidden /> Falar no WhatsApp
        </a>
      </div>
      <p className="mt-6 text-sm text-slate-500">
        Ou acesse: <Link href="/servicos" className="underline">Serviços</Link> ·{" "}
        <Link href="/sobre" className="underline">Sobre nós</Link> ·{" "}
        <Link href="/contato" className="underline">Contato</Link>
      </p>
    </section>
  );
}
