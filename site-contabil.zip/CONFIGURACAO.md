# CONFIGURAÇÃO — o que falta preencher para ativar 100%

O site já funciona visualmente sem nenhuma chave. Para operação real, preencha:

## 1. Dados do escritório (obrigatório)
Edite `src/site.ts`:
- `whatsappNumero`: DDI+DDD+número só dígitos (ex: `5511999999999`)
- `telefoneExibicao` e `telefoneHref`
- `email`
- `endereco` (rua, cidade, UF, CEP, mapsUrl)
- `urlBase`: domínio final (ex: `https://www.seuescritorio.com.br`)
- `redes`: URLs reais de Instagram/LinkedIn/Facebook
- `nome` / `nomeCompleto` se a marca for diferente de CONTÁBIL

## 2. Envio do formulário (obrigatório para receber leads por e-mail)
O formulário valida no front + back (`src/app/api/contact/route.ts`).
Sem chaves, a API retorna **503 com mensagem clara** (não simula envio).

Para ativar:
1. Crie conta em https://resend.com e valide o domínio.
2. Crie `.env.local` na raiz:
   ```
   RESEND_API_KEY=re_sua_chave
   CONTACT_TO_EMAIL=contato@seuescritorio.com.br
   CONTACT_FROM_EMAIL=site@seuescritorio.com.br
   ```
3. Reinicie o servidor (`npm run dev` / redeploy).

Alternativa sem Resend: adapte `route.ts` para seu SMTP/Nodemailer ou webhook (CRM).
O fallback atual é o botão de WhatsApp com mensagem pré-preenchida.

## 3. Sobre nós (conteúdo provisório)
Edite `src/app/sobre/page.tsx`:
- História do escritório
- Nome + CRC do responsável técnico
- Equipe

## 4. Domínio e SEO local
- Atualize `site.urlBase` e faça deploy (Vercel recomendada).
- Cadastre o endereço no Google Business Profile.
- O sitemap fica em `/sitemap.xml` e robots em `/robots.txt` (gerados automaticamente).

## 5. LGPD
- Revise `src/app/privacidade/page.tsx` com um advogado.
- O banner de consentimento (`CookieConsent.tsx`) usa apenas localStorage, sem rastreadores.

## 6. Credenciais
Nenhuma chave está exposta no frontend. `RESEND_API_KEY` fica só no servidor (API route).
