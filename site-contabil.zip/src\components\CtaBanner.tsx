import { MessageCircle, ArrowRight } from "lucide-react";
import Link from "next/link";
import { site, whatsappLink } from "@/site";

export default function CtaBanner() {
  return (
    <section aria-labelledby="cta-titulo" className="mx-auto max-w-6xl px-5 py-16 sm:py-20">
      <div className="relative overflow-hidden rounded-3xl bg-navy-900 px-6 py-12 text-center text-white sm:px-12">
        <div aria-hidden className="absolute inset-0 bg-[radial-gradient(600px_260px_at_50%_-20%,rgba(35,136,92,.45),transparent)]" />
        <div className="relative">
          <h2 id="cta-titulo" className="mx-auto max-w-2xl font-display text-3xl font-bold sm:text-4xl">
            Vamos cuidar da contabilidade da sua empresa?
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-white/75">
            Envie sua dúvida ou peça uma proposta. Retornamos no horário comercial ({site.horario}).
          </p>
          <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
            <a
              href={whatsappLink(site.whatsappMensagens.proposta)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-brand-500 px-6 py-3.5 font-semibold text-white transition hover:bg-brand-600"
            >
              <MessageCircle className="h-5 w-5" aria-hidden />
              Conversar pelo WhatsApp
            </a>
            <Link
              href="/contato"
              className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/25 px-6 py-3.5 font-semibold text-white transition hover:bg-white/10"
            >
              Preencher formulário <ArrowRight className="h-5 w-5" aria-hidden />
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
