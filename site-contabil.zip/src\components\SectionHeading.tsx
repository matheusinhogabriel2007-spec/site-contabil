export default function SectionHeading({
  id,
  eyebrow,
  titulo,
  descricao,
  align = "left",
}: {
  id?: string;
  eyebrow: string;
  titulo: string;
  descricao?: string;
  align?: "left" | "center";
}) {
  const alinhamento = align === "center" ? "text-center mx-auto" : "";
  return (
    <div className={`max-w-2xl ${alinhamento}`}>
      <p className="text-xs font-bold uppercase tracking-[0.18em] text-brand-600">{eyebrow}</p>
      <h2 id={id} className="mt-2 font-display text-3xl font-bold tracking-tight text-navy-900 sm:text-4xl">
        {titulo}
      </h2>
      {descricao && <p className="mt-3 leading-relaxed text-slate-600">{descricao}</p>}
    </div>
  );
}
