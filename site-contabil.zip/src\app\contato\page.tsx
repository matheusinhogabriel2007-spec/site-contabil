import type { Metadata } from "next";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
import { site, whatsappLink } from "@/site";
import ContactForm from "@/components/ContactForm";

export const metadata: Metadata = {
  title: "Contato",
  description: "Fale com um contador: peça uma proposta ou tire dúvidas sobre abertura, MEI, impostos e rotinas contábeis.",
};

export default function ContatoPage() {
  return (
    <>
      <section className="bg-navy-950 text-white">
        <div className="mx-auto max-w-6xl px-5 py-14 sm:py-16">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-300">Contato</p>
          <h1 className="mt-2 max-w-2xl font-display text-3xl font-bold sm:text-4xl">
            Fale com um contador
          </h1>
          <p className="mt-3 max-w-2xl text-white/75">
            Preencha o formulário ou chame no WhatsApp. Retornamos em {site.horario}.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-8 px-5 py-14 lg:grid-cols-[.9fr_1.1fr]">
        <aside className="space-y-4">
          <a
            href={whatsappLink(site.whatsappMensagens.geral)}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-4 rounded-2xl bg-[#25D366]/10 p-5 ring-1 ring-[#25D366]/30 transition hover:bg-[#25D366]/15"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#25D366] text-white">
              <MessageCircle className="h-6 w-6" aria-hidden />
            </span>
            <span>
              <span className="block font-semibold text-navy-900">WhatsApp — resposta rápida</span>
              <span className="block text-sm text-slate-600">{site.telefoneExibicao}</span>
            </span>
          </a>
          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <ul className="space-y-3 text-sm">
              <li>
                <a href={site.telefoneHref} className="flex items-center gap-2.5 text-slate-700 hover:text-navy-900">
                  <Phone className="h-4 w-4 text-brand-600" aria-hidden /> {site.telefoneExibicao}
                </a>
              </li>
              <li>
                <a href={`mailto:${site.email}`} className="flex items-center gap-2.5 break-all text-slate-700 hover:text-navy-900">
                  <Mail className="h-4 w-4 shrink-0 text-brand-600" aria-hidden /> {site.email}
                </a>
              </li>
              <li>
                <a href={site.endereco.mapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-start gap-2.5 text-slate-700 hover:text-navy-900">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" aria-hidden />
                  <span>{site.endereco.rua}<br />{site.endereco.cidade}–{site.endereco.uf} · {site.endereco.cep}</span>
                </a>
              </li>
            </ul>
          </div>
          <div className="rounded-2xl bg-slate-50 p-5 text-sm leading-relaxed text-slate-600">
            <p className="font-semibold text-navy-900">O que acontece após o envio?</p>
            <p className="mt-1">1. Confirmamos o recebimento no horário comercial.<br />2. Pedimos informações complementares, se necessário.<br />3. Enviamos escopo e honorários de forma transparente.</p>
          </div>
        </aside>
        <ContactForm />
      </section>
    </>
  );
}
