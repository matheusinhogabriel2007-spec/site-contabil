import type { MetadataRoute } from "next";
import { site } from "@/site";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = site.urlBase.replace(/\/$/, "");
  const agora = new Date();
  const rotas = ["", "/servicos", "/sobre", "/contato", "/privacidade"];
  return rotas.map((r) => ({
    url: `${base}${r || "/"}`,
    lastModified: agora,
    changeFrequency: r === "" ? "weekly" : "monthly",
    priority: r === "" ? 1 : 0.8,
  }));
}
