import type { Metadata } from "next";
import { ArrowRight, CheckCircle2, MessageCircle } from "lucide-react";
import { servicos, site, whatsappLink } from "@/site";
import SectionHeading from "@/components/SectionHeading";
import CtaBanner from "@/components/CtaBanner";

export const metadata: Metadata = {
  title: "Serviços contábeis",
  description:
    "Abertura de empresas, contabilidade empresarial, planejamento tributário, fiscal, departamento pessoal, MEI e consultoria.",
};

export default function ServicosPage() {
  return (
    <>
      <section className="bg-navy-950 text-white">
        <div className="mx-auto max-w-6xl px-5 py-14 sm:py-16">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-300">Serviços</p>
          <h1 className="mt-2 max-w-2xl font-display text-3xl font-bold sm:text-4xl">
            Serviços contábeis para organizar e acompanhar sua empresa
          </h1>
          <p className="mt-3 max-w-2xl text-white/75">
            Escopo transparente, rotina mensal definida e comunicação direta. Clique em um serviço
            para falar com a equipe sobre o seu caso.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-14">
        <div className="grid gap-6 lg:grid-cols-2">
          {servicos.map((s) => {
            const msg = `Olá! Gostaria de saber mais sobre: ${s.titulo}.`;
            return (
              <article key={s.id} id={s.id} className="scroll-mt-24 rounded-2xl border border-slate-200 bg-white p-7 shadow-card">
                <h2 className="font-display text-xl font-bold text-navy-900">{s.titulo}</h2>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">{s.descricao}</p>
                <ul className="mt-4 space-y-2">
                  {s.detalhes.map((d) => (
                    <li key={d} className="flex items-start gap-2 text-sm text-slate-700">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-600" aria-hidden />
                      {d}
                    </li>
                  ))}
                </ul>
                <div className="mt-5 flex flex-wrap gap-2">
                  <a
                    href={whatsappLink(msg)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-brand-700"
                  >
                    <MessageCircle className="h-4 w-4" aria-hidden />
                    Saber mais no WhatsApp
                  </a>
                  <a
                    href="/contato"
                    className="inline-flex items-center gap-1.5 rounded-xl border border-slate-300 px-5 py-2.5 text-sm font-semibold text-navy-900 transition hover:bg-slate-50"
                  >
                    Pedir proposta <ArrowRight className="h-4 w-4" aria-hidden />
                  </a>
                </div>
              </article>
            );
          })}
        </div>

        <div className="mt-10 rounded-2xl bg-slate-50 p-6 text-sm leading-relaxed text-slate-600">
          <p>
            <strong className="text-navy-900">Não sabe qual serviço contratar?</strong> Envie o
            formulário em <a href="/contato" className="font-semibold text-brand-700 underline underline-offset-2">Contato</a>{" "}
            ou chame no WhatsApp ({site.telefoneExibicao}). Analisamos o momento da sua empresa e
            indicamos o escopo adequado — sem compromisso.
          </p>
        </div>

        <SectionHeading
          eyebrow="Transparência"
          titulo="O que está incluído em uma proposta?"
          descricao="Toda proposta informa escopo, rotina mensal, prazos, documentos necessários, honorários e condições de reajuste. Nada de taxas ocultas."
        />
      </section>

      <CtaBanner />
    </>
  );
}
