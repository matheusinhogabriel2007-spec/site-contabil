import type { Metadata } from "next";
import { Inter, Sora } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";
import CookieConsent from "@/components/CookieConsent";
import { site } from "@/site";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const sora = Sora({ subsets: ["latin"], variable: "--font-sora", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(site.urlBase),
  title: {
    default: `${site.nome} — Contabilidade para empresas | ${site.endereco.cidade} ${site.endereco.uf}`,
    template: `%s | ${site.nome}`,
  },
  description: site.descricao,
  keywords: [
    "contabilidade",
    "contador",
    "abertura de empresa",
    "MEI",
    "planejamento tributário",
    "departamento fiscal",
    "departamento pessoal",
    "escritório de contabilidade",
    site.endereco.cidade,
  ],
  authors: [{ name: site.nomeCompleto }],
  creator: site.nomeCompleto,
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: site.urlBase,
    siteName: site.nomeCompleto,
    title: `${site.nome} — Sua empresa cresce. Sua contabilidade acompanha.`,
    description: site.descricao,
  },
  twitter: { card: "summary_large_image" },
  robots: { index: true, follow: true },
  alternates: { canonical: site.urlBase },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "AccountingService",
    name: site.nomeCompleto,
    description: site.descricao,
    url: site.urlBase,
    telephone: site.telefoneHref.replace("tel:", ""),
    email: site.email,
    address: {
      "@type": "PostalAddress",
      streetAddress: site.endereco.rua,
      addressLocality: site.endereco.cidade,
      addressRegion: site.endereco.uf,
      postalCode: site.endereco.cep,
      addressCountry: "BR",
    },
    openingHours: "Mo-Fr 08:00-18:00",
    areaServed: "BR",
    priceRange: "$$",
  };

  return (
    <html lang="pt-BR">
      <body className={`${inter.variable} ${sora.variable} font-sans min-h-screen flex flex-col`}>
        <a
          href="#conteudo"
          className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-[100] focus:bg-navy-900 focus:text-white focus:px-4 focus:py-2 focus:rounded"
        >
          Pular para o conteúdo
        </a>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <Header />
        <main id="conteudo" className="flex-1">
          {children}
        </main>
        <Footer />
        <WhatsAppFloat />
        <CookieConsent />
      </body>
    </html>
  );
}
