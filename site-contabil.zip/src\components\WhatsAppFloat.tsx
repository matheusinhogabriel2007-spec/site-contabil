import { MessageCircle } from "lucide-react";
import { site, whatsappLink } from "@/site";

export default function WhatsAppFloat() {
  return (
    <a
      href={whatsappLink(site.whatsappMensagens.geral)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Conversar no WhatsApp"
      className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-soft transition hover:scale-105 hover:bg-[#1eb856]"
    >
      <MessageCircle className="h-7 w-7" aria-hidden />
    </a>
  );
}
