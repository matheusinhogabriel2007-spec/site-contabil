import Link from "next/link";
import { Calculator, Mail, MapPin, Phone, Clock } from "lucide-react";
import { site, servicos } from "@/site";

export default function Footer() {
  return (
    <footer className="bg-navy-950 text-white" aria-label="Rodapé">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10">
              <Calculator className="h-5 w-5" aria-hidden />
            </span>
            <span className="font-display text-xl font-bold">
              {site.nome}<span className="text-emerald-300">.</span>
            </span>
          </p>
          <p className="mt-4 text-sm leading-relaxed text-white/70">{site.tagline}</p>
          <p className="mt-3 flex items-start gap-2 text-sm text-white/70">
            <Clock className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
            {site.horario}
          </p>
        </div>

        <nav aria-label="Navegação do rodapé">
          <p className="text-sm font-semibold uppercase tracking-wider text-white/60">Navegação</p>
          <ul className="mt-4 space-y-2.5 text-sm">
            {[
              ["/", "Início"],
              ["/servicos", "Serviços"],
              ["/sobre", "Sobre nós"],
              ["/contato", "Contato"],
              ["/privacidade", "Política de privacidade"],
            ].map(([href, label]) => (
              <li key={href}>
                <Link href={href} className="text-white/80 transition hover:text-white hover:underline">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <nav aria-label="Serviços no rodapé">
          <p className="text-sm font-semibold uppercase tracking-wider text-white/60">Serviços</p>
          <ul className="mt-4 space-y-2.5 text-sm">
            {servicos.slice(0, 6).map((s) => (
              <li key={s.id}>
                <Link href={`/servicos#${s.id}`} className="text-white/80 transition hover:text-white hover:underline">
                  {s.titulo}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="text-sm font-semibold uppercase tracking-wider text-white/60">Contato</p>
          <ul className="mt-4 space-y-3 text-sm text-white/80">
            <li>
              <a href={site.telefoneHref} className="flex items-center gap-2 hover:text-white">
                <Phone className="h-4 w-4 shrink-0" aria-hidden />
                {site.telefoneExibicao}
              </a>
            </li>
            <li>
              <a href={`mailto:${site.email}`} className="flex items-center gap-2 break-all hover:text-white">
                <Mail className="h-4 w-4 shrink-0" aria-hidden />
                {site.email}
              </a>
            </li>
            <li>
              <a href={site.endereco.mapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-start gap-2 hover:text-white">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
                <span>
                  {site.endereco.rua}
                  <br />
                  {site.endereco.cidade}–{site.endereco.uf} · {site.endereco.cep}
                </span>
              </a>
            </li>
          </ul>
          <div className="mt-4 flex gap-2 text-xs">
            <a href={site.redes.instagram} target="_blank" rel="noopener noreferrer" className="rounded-lg border border-white/20 px-3 py-1.5 text-white/80 hover:bg-white/10">Instagram</a>
            <a href={site.redes.linkedin} target="_blank" rel="noopener noreferrer" className="rounded-lg border border-white/20 px-3 py-1.5 text-white/80 hover:bg-white/10">LinkedIn</a>
            <a href={site.redes.facebook} target="_blank" rel="noopener noreferrer" className="rounded-lg border border-white/20 px-3 py-1.5 text-white/80 hover:bg-white/10">Facebook</a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-6xl flex-col gap-1 px-5 py-5 text-xs text-white/55 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} {site.nomeCompleto}. Todos os direitos reservados.</p>
          <p>Conteúdo provisório — substitua pelos dados oficiais do escritório e CRC do responsável.</p>
        </div>
      </div>
    </footer>
  );
}
