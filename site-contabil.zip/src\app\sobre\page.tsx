import type { Metadata } from "next";
import { Compass, Eye, HeartHandshake } from "lucide-react";
import SectionHeading from "@/components/SectionHeading";
import CtaBanner from "@/components/CtaBanner";

export const metadata: Metadata = {
  title: "Sobre nós",
  description:
    "Conheça a metodologia de trabalho, os valores e o compromisso do escritório com os clientes.",
};

export default function SobrePage() {
  return (
    <>
      <section className="bg-navy-950 text-white">
        <div className="mx-auto max-w-6xl px-5 py-14 sm:py-16">
          <p className="text-xs font-bold uppercase tracking-[0.18em] text-emerald-300">Sobre nós</p>
          <h1 className="mt-2 max-w-2xl font-display text-3xl font-bold sm:text-4xl">
            Um escritório organizado para empresas que levam a gestão a sério
          </h1>
          <p className="mt-3 max-w-2xl text-white/75">
            Conteúdo institucional provisório e editável — substitua pelos dados oficiais do
            escritório (história, equipe, CRC do responsável técnico).
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-14">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <SectionHeading
              eyebrow="Apresentação"
              titulo="Quem somos"
              descricao="Somos um escritório de contabilidade que atende micro, pequenas e médias empresas em todo o Brasil, com foco em rotina organizada, prazos cumpridos e informação útil para a decisão do empresário."
            />
            <div className="mt-6 space-y-4 text-sm leading-relaxed text-slate-600">
              <p>
                <strong className="text-navy-900">[Editar]</strong> Descreva aqui a história do
                escritório: ano de fundação, cidade de origem, perfil de clientes atendidos e áreas
                de especialização. Evite números ou certificações que não possam ser comprovados.
              </p>
              <p>
                <strong className="text-navy-900">[Editar]</strong> Apresente o responsável técnico
                (nome e CRC) e a equipe. Exemplo: “Responsável técnico: Nome Sobrenome — CRC/UF
                000000/O”.
              </p>
            </div>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-7">
            <h2 className="font-display text-lg font-bold text-navy-900">Metodologia de trabalho</h2>
            <ol className="mt-4 space-y-4 text-sm leading-relaxed text-slate-600">
              <li><strong className="text-navy-900">1. Diagnóstico inicial.</strong> Levantamento da situação fiscal, contábil e trabalhista da empresa.</li>
              <li><strong className="text-navy-900">2. Organização.</strong> Definição de canal de envio, checklist mensal e calendário de vencimentos.</li>
              <li><strong className="text-navy-900">3. Rotina mensal.</strong> Escrituração, apurações, folha e conferências com controle de entregas.</li>
              <li><strong className="text-navy-900">4. Leitura para decisão.</strong> Relatórios e pontos de atenção explicados em linguagem simples.</li>
            </ol>
          </div>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {[
            { icone: <Compass className="h-6 w-6" aria-hidden />, titulo: "Clareza", texto: "Explicamos obrigações e prazos de forma objetiva, sem prometer resultados que não dependem só da contabilidade." },
            { icone: <Eye className="h-6 w-6" aria-hidden />, titulo: "Transparência", texto: "Proposta com escopo e honorários claros, sem taxas ocultas e com registro das entregas mensais." },
            { icone: <HeartHandshake className="h-6 w-6" aria-hidden />, titulo: "Compromisso", texto: "Acompanhamento próximo da rotina da empresa e retorno no horário comercial combinado." },
          ].map((v) => (
            <div key={v.titulo} className="rounded-2xl border border-slate-200 bg-white p-6">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-navy-900 text-white">{v.icone}</div>
              <h3 className="mt-3 font-display font-semibold text-navy-900">{v.titulo}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-600">{v.texto}</p>
            </div>
          ))}
        </div>
      </section>

      <CtaBanner />
    </>
  );
}
