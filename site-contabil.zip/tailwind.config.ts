/** @type {import('tailwindcss').Config} */
const config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: {
          50: "#eef3fa",
          100: "#d8e3f2",
          200: "#b3c8e4",
          300: "#84a5d1",
          400: "#547fbb",
          500: "#35619e",
          600: "#264c82",
          700: "#1e3d69",
          800: "#14294a",
          900: "#0b1c36",
          950: "#071325",
        },
        brand: {
          50: "#eef7f1",
          100: "#d7ecdf",
          200: "#b0d9c1",
          300: "#7fbf9c",
          400: "#4da376",
          500: "#23885c",
          600: "#18714b",
          700: "#14593e",
          800: "#124733",
          900: "#0f3a2b",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        display: ["var(--font-sora)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        soft: "0 10px 40px -12px rgba(11,28,54,.18)",
        card: "0 4px 24px -6px rgba(11,28,54,.12)",
      },
    },
  },
  plugins: [],
};

export default config;
