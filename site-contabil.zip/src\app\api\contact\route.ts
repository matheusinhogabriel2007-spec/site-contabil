import { NextResponse } from "next/server";

function isEmail(v: unknown): boolean {
  return typeof v === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());
}

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ erro: "Dados inválidos." }, { status: 400 });
  }

  const nome = String(body.nome ?? "").trim();
  const empresa = String(body.empresa ?? "").trim();
  const telefone = String(body.telefone ?? "").trim();
  const email = String(body.email ?? "").trim();
  const servico = String(body.servico ?? "").trim();
  const mensagem = String(body.mensagem ?? "").trim();
  const lgpd = body.lgpd === true;

  if (nome.length < 2) return NextResponse.json({ erro: "Informe seu nome." }, { status: 400 });
  if (empresa.length < 2) return NextResponse.json({ erro: "Informe o nome da empresa." }, { status: 400 });
  if (telefone.replace(/\D/g, "").length < 10)
    return NextResponse.json({ erro: "Informe um telefone válido com DDD." }, { status: 400 });
  if (!isEmail(email)) return NextResponse.json({ erro: "Informe um e-mail válido." }, { status: 400 });
  if (!servico) return NextResponse.json({ erro: "Selecione o serviço desejado." }, { status: 400 });
  if (mensagem.length < 10)
    return NextResponse.json({ erro: "Descreva sua necessidade com mais detalhes." }, { status: 400 });
  if (!lgpd) return NextResponse.json({ erro: "Autorização LGPD obrigatória." }, { status: 400 });

  // ---------------------------------------------------------------
  // INTEGRAÇÃO REAL:
  // - Se RESEND_API_KEY + CONTACT_TO_EMAIL estiverem configurados,
  //   envia o e-mail via Resend (https://resend.com).
  // - Caso contrário, retorna 503 com instrução clara (sem simular envio).
  // Veja CONFIGURACAO.md para ativar.
  // ---------------------------------------------------------------
  const resendKey = process.env.RESEND_API_KEY;
  const destino = process.env.CONTACT_TO_EMAIL;
  const remetente = process.env.CONTACT_FROM_EMAIL ?? "site@contabil.exemplo.com.br";

  if (!resendKey || !destino) {
    console.warn("[contato] recebido, porém e-mail não configurado:", { nome, empresa, email, servico });
    return NextResponse.json(
      {
        erro: "Envio por e-mail ainda não configurado neste site. Preencha RESEND_API_KEY e CONTACT_TO_EMAIL no servidor (veja CONFIGURACAO.md) ou fale pelo WhatsApp.",
      },
      { status: 503 }
    );
  }

  try {
    const resp = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${resendKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: remetente,
        to: [destino],
        reply_to: email,
        subject: `Novo contato do site — ${empresa} (${servico})`,
        text: [
          `Nome: ${nome}`,
          `Empresa: ${empresa}`,
          `Telefone: ${telefone}`,
          `E-mail: ${email}`,
          `Serviço: ${servico}`,
          ``,
          mensagem,
        ].join("\n"),
      }),
    });
    if (!resp.ok) {
      const detalhe = await resp.text().catch(() => "");
      console.error("[contato] falha Resend:", detalhe);
      return NextResponse.json({ erro: "Falha ao enviar. Tente pelo WhatsApp." }, { status: 502 });
    }
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("[contato] erro:", e);
    return NextResponse.json({ erro: "Erro interno. Tente pelo WhatsApp." }, { status: 500 });
  }
}
