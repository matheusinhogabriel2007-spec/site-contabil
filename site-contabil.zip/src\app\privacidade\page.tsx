import type { Metadata } from "next";
import { site } from "@/site";

export const metadata: Metadata = {
  title: "Política de privacidade",
  description: "Como tratamos os dados enviados pelo site, conforme a LGPD.",
};

export default function PrivacidadePage() {
  return (
    <section className="mx-auto max-w-3xl px-5 py-14">
      <p className="text-xs font-bold uppercase tracking-[0.18em] text-brand-600">LGPD</p>
      <h1 className="mt-2 font-display text-3xl font-bold text-navy-900 sm:text-4xl">
        Política de privacidade
      </h1>
      <p className="mt-3 text-sm text-slate-500">Última atualização: outubro de 2026 · Modelo inicial — revise com um advogado.</p>
      <div className="prose-sm mt-8 space-y-5 text-sm leading-relaxed text-slate-700">
        <section>
          <h2 className="font-display font-semibold text-navy-900">1. Dados que coletamos</h2>
          <p>Coletamos apenas os dados enviados voluntariamente no formulário de contato: nome, nome da empresa, telefone, e-mail, serviço desejado e mensagem, além do registro de consentimento.</p>
        </section>
        <section>
          <h2 className="font-display font-semibold text-navy-900">2. Finalidade</h2>
          <p>Os dados são usados exclusivamente para retornar o contato, elaborar proposta e manter comunicação comercial, com base no consentimento (art. 7º, I, LGPD).</p>
        </section>
        <section>
          <h2 className="font-display font-semibold text-navy-900">3. Compartilhamento</h2>
          <p>Não vendemos dados. O envio de e-mails pode usar operadores (ex.: Resend) apenas para viabilizar o contato. WhatsApp e mapas seguem as políticas dos respectivos provedores.</p>
        </section>
        <section>
          <h2 className="font-display font-semibold text-navy-900">4. Retenção e direitos</h2>
          <p>Mantemos os contatos pelo tempo necessário ao atendimento. Você pode solicitar acesso, correção ou exclusão pelo e-mail {site.email}.</p>
        </section>
        <section>
          <h2 className="font-display font-semibold text-navy-900">5. Cookies</h2>
          <p>Utilizamos apenas armazenamento local para lembrar o aceite deste aviso. Não usamos rastreamento publicitário próprio.</p>
        </section>
        <section>
          <h2 className="font-display font-semibold text-navy-900">6. Contato do controlador</h2>
          <p>{site.nomeCompleto} · {site.email} · {site.telefoneExibicao} · {site.endereco.rua}, {site.endereco.cidade}–{site.endereco.uf}.</p>
        </section>
      </div>
    </section>
  );
}
