"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, Calculator, PhoneCall } from "lucide-react";
import { site, whatsappLink } from "@/site";

const links = [
  { href: "/", label: "Início" },
  { href: "/servicos", label: "Serviços" },
  { href: "/sobre", label: "Sobre nós" },
  { href: "/contato", label: "Contato" },
];

export default function Header() {
  const [aberto, setAberto] = useState(false);
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/80 bg-white/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <Link href="/" className="flex items-center gap-2.5" aria-label={`${site.nome} — início`}>
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy-900 text-white">
            <Calculator className="h-5 w-5" aria-hidden />
          </span>
          <span className="font-display text-xl font-bold tracking-tight text-navy-900">
            {site.nome}
            <span className="text-brand-600">.</span>
          </span>
        </Link>

        <nav aria-label="Navegação principal" className="hidden items-center gap-1 md:flex">
          {links.map((l) => {
            const ativo = pathname === l.href;
            return (
              <Link
                key={l.href}
                href={l.href}
                aria-current={ativo ? "page" : undefined}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition ${
                  ativo ? "bg-slate-100 text-navy-900" : "text-slate-600 hover:bg-slate-50 hover:text-navy-900"
                }`}
              >
                {l.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden md:block">
          <a
            href={whatsappLink(site.whatsappMensagens.geral)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-xl bg-navy-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-navy-800"
          >
            <PhoneCall className="h-4 w-4" aria-hidden />
            Fale com um especialista
          </a>
        </div>

        <button
          type="button"
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 md:hidden"
          aria-expanded={aberto}
          aria-label={aberto ? "Fechar menu" : "Abrir menu"}
          onClick={() => setAberto((v) => !v)}
        >
          {aberto ? <X className="h-5 w-5" aria-hidden /> : <Menu className="h-5 w-5" aria-hidden />}
        </button>
      </div>

      {aberto && (
        <nav aria-label="Menu móvel" className="border-t border-slate-200 bg-white px-5 py-4 md:hidden">
          <ul className="space-y-1">
            {links.map((l) => (
              <li key={l.href}>
                <Link
                  href={l.href}
                  onClick={() => setAberto(false)}
                  aria-current={pathname === l.href ? "page" : undefined}
                  className={`block rounded-lg px-3 py-2.5 font-medium ${
                    pathname === l.href ? "bg-slate-100 text-navy-900" : "text-slate-700"
                  }`}
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
          <a
            href={whatsappLink(site.whatsappMensagens.geral)}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 flex items-center justify-center gap-2 rounded-xl bg-navy-900 px-5 py-3 font-semibold text-white"
          >
            <PhoneCall className="h-4 w-4" aria-hidden />
            Fale com um especialista
          </a>
        </nav>
      )}
    </header>
  );
}
