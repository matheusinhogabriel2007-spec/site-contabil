# Como executar o site

## Pré-requisitos
- Node.js 18.18+ ou 20+

## Instalação e execução

```bash
npm install
npm run dev
```

Abra http://localhost:3000

## Verificações

```bash
npm run typecheck
npm run build
npm run start
```

## Estrutura
- `src/site.ts` — configuração central (telefone, WhatsApp, e-mail, endereço, serviços, FAQ)
- `src/app/` — páginas (início, serviços, sobre, contato, privacidade, 404, sitemap, robots, API)
- `src/components/` — Header, Footer, WhatsAppFloat, ContactForm, Faq, CtaBanner, CookieConsent
- `src/app/api/contact/route.ts` — endpoint real do formulário (valida e envia via Resend se configurado)
